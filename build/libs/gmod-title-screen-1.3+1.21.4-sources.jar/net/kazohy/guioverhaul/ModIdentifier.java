package net.kazohy.guioverhaul;

import net.minecraft.class_2960;

public final class ModIdentifier {
  public static class_2960 of(String path) {
    return class_2960.method_60655("gmod-title-screen", path);
  }
}