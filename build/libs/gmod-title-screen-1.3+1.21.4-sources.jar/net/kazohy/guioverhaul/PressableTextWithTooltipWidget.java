package net.kazohy.guioverhaul;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_7077;
import net.minecraft.class_7919;

@Environment(EnvType.CLIENT)
public class PressableTextWithTooltipWidget extends class_7077 {
  protected final class_7919 tooltip;

  public PressableTextWithTooltipWidget(int x, int y, int width, int height, class_2561 text, class_4241 onPress, class_327 textRenderer, class_7919 tooltip) {
    super(x, y, width, height, text, onPress, textRenderer);
    this.tooltip = tooltip;
    method_47400(tooltip);
  }
}
