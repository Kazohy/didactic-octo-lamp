package net.kazohy.guioverhaul.screen;

import java.nio.file.Files;
import java.nio.file.Paths;
import org.slf4j.Logger;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import net.minecraft.class_10142;
import net.minecraft.class_1049;
import net.minecraft.class_1060;
import net.minecraft.class_1071;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_412;
import net.minecraft.class_4189;
import net.minecraft.class_429;
import net.minecraft.class_4325;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_4587;
import net.minecraft.class_500;
import net.minecraft.class_526;
import net.minecraft.class_5599;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_7077;
import net.minecraft.class_7833;
import net.minecraft.class_8020;
import net.minecraft.class_8519;
import net.minecraft.class_8666;
import net.minecraft.class_8685;
import net.minecraft.class_8765;
import net.minecraft.class_9112;
import net.minecraft.client.gui.screen.*;
import java.nio.file.Path;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;
import org.slf4j.LoggerFactory;
import net.kazohy.guioverhaul.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.function.Supplier;

import com.mojang.authlib.GameProfile;
import net.kazohy.guioverhaul.listener.WorldCreationListener;

import java.util.Optional;
import java.util.Objects;

import static net.fabricmc.loader.impl.FabricLoaderImpl.MOD_ID;
import static net.kazohy.guioverhaul.WorldUtils.getWorldGameMode;
import static net.kazohy.guioverhaul.listener.WorldCreationListener.getMostRecentlyCreatedWorld;

@Environment(EnvType.CLIENT)
public class CustomTitleScreen extends class_437 {
    private long startTime = System.currentTimeMillis();
    private long lastPauseTime = 0;
    private boolean isPaused = false;
    private boolean hasPausedThisLoop = false;

    private static String lastLoadedWorld = "";
    @Nullable
    private class_2960 lastWorldIconTexture;
    public static int screenWidth;
    public static int screenHeight;

    private final class_8020 logoDrawer;

    @Nullable
    private class_8519 splashText;

    private static final class_2960 GMOD_TITLE_TEXTURE = ModIdentifier.of("textures/gui/title/gmod_title.png");
    private static final class_2960 AESTHETIC_ELEMENT_DOWN = ModIdentifier.of("textures/gui/title/aesthetic_element_down.png");
    private static final class_2960 AESTHETIC_ELEMENT_UP = ModIdentifier.of("textures/gui/title/aesthetic_elemnt_up.png");
    private static final class_2960 NORMAL_BUTTON_TEXTURE = ModIdentifier.of("textures/gui/title/normal_button.png");
    private static final class_2960 REALMS_BUTTON_TEXTURE = ModIdentifier.of("textures/gui/title/realms_button.png");
    private static final class_2960 NEWS_BUTTON_TEXTURE = ModIdentifier.of("textures/gui/title/news_button.png");
    private static final class_2960 PLAYER_WIDGET_BUTTON = ModIdentifier.of("textures/gui/title/player_widget.png");
    private static final class_2960 RECENTS_BUTTONS = ModIdentifier.of("textures/gui/title/recents_buttons.png");

    public CustomTitleScreen() {
        this(null);
    }

    public static void registerTextures(class_1060 textureManager) {
        textureManager.method_65876(GMOD_TITLE_TEXTURE, new class_1049(GMOD_TITLE_TEXTURE));
        textureManager.method_65876(AESTHETIC_ELEMENT_DOWN, new class_1049(AESTHETIC_ELEMENT_DOWN));
        textureManager.method_65876(AESTHETIC_ELEMENT_UP, new class_1049(AESTHETIC_ELEMENT_UP));
        textureManager.method_65876(NORMAL_BUTTON_TEXTURE, new class_1049(NORMAL_BUTTON_TEXTURE));
        textureManager.method_65876(REALMS_BUTTON_TEXTURE, new class_1049(REALMS_BUTTON_TEXTURE));
        textureManager.method_65876(NEWS_BUTTON_TEXTURE, new class_1049(NEWS_BUTTON_TEXTURE));
        textureManager.method_65876(PLAYER_WIDGET_BUTTON, new class_1049(PLAYER_WIDGET_BUTTON));
        textureManager.method_65876(RECENTS_BUTTONS, new class_1049(RECENTS_BUTTONS));
        SlideshowBackground.registerBackgroundTextures(textureManager);
    }

    public CustomTitleScreen(@Nullable class_8020 logoDrawer) {
        super(class_2561.method_43471("narrator.screen.title"));
        this.logoDrawer = Objects.requireNonNullElseGet(logoDrawer, () -> new class_8020(false));
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return false;
    }


    private int getLogoY() {
        if (Mod.config.showGModLogo) {
            return this.field_22790 / 32;
        } else {
            return this.field_22790 / 12;
        }
    }

    @Override
    protected void method_25426() {
        if (this.splashText == null) {
            assert this.field_22787 != null;
            this.splashText = this.field_22787.method_18095().method_18174();
        }

        screenWidth = this.field_22789;
        screenHeight = this.field_22790;

        int playerWidgetX = this.field_22789 / 2 + this.field_22789 * (59 / 2) / 1800;
        int playerWidgetY = this.field_22790 / 2 - this.field_22790 * 298 / 1080 + 279 * this.field_22790 / 1080;
        int playerWidgetWidth = 409 * this.field_22789 / 1800;
        int playerWidgetHeight = playerWidgetWidth * 280 / 409;

        GameProfile profile;
        assert field_22787 != null;
        if (field_22787.field_1724 != null) {
            profile = field_22787.field_1724.method_7334();
        } else {
            String username = field_22787.method_1548().method_1676();
            profile = new GameProfile(
                    UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8)),
                    username
            );
        }

        class_1071 skinProvider = class_310.method_1551().method_1582();
        Supplier<class_8685> skinSupplier = skinProvider.method_52858(profile);
        class_5599 models = class_310.method_1551().method_31974();
        class_8765 playerSkin = new class_8765(64, 88, models, skinSupplier);

        this.method_37063(playerSkin);
        playerSkin.method_48229(playerWidgetX + playerWidgetWidth / 2 - 32, playerWidgetY + playerWidgetHeight / 2 - 44);

        RenderSystem.setShaderTexture(0, NORMAL_BUTTON_TEXTURE);
        RenderSystem.setShaderTexture(1, NORMAL_BUTTON_TEXTURE);
        RenderSystem.setShaderTexture(2, NORMAL_BUTTON_TEXTURE);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);

        class_8666 normalButtonTextures = new class_8666(
                NORMAL_BUTTON_TEXTURE,
                NORMAL_BUTTON_TEXTURE,
                NORMAL_BUTTON_TEXTURE
        );

        int buttonWidth = 408 * this.field_22789 / 1800;
        int buttonheight = buttonWidth * 68 / 408;
        int buttonX = this.field_22789 / 2 - buttonWidth - this.field_22789 * (59 / 2) / 1800;
        int buttonY = this.field_22790 / 2 - this.field_22790 * 298 / 1080;

        this.method_37063(new class_344(
                buttonX,
                buttonY,
                buttonWidth,
                buttonheight,
                normalButtonTextures,
                button -> this.field_22787.method_1507(new class_526(this)),
                class_2561.method_43470("Options")
        ));

        this.method_37063(new class_344(
                buttonX,
                buttonY + this.field_22790 * 17 / 1080 + buttonheight,
                buttonWidth,
                buttonheight,
                normalButtonTextures,
                button -> this.field_22787.method_1507(new class_500(this)),
                class_2561.method_43470("Options")
        ));

        boolean modsButtonActive = FabricLoader.getInstance().isModLoaded("modmenu");

        this.method_37063(new class_344(
                buttonX,
                buttonY + 3 * (this.field_22790 * 17 / 1080 + buttonheight),
                buttonWidth,
                buttonheight,
                normalButtonTextures,
                button -> this.field_22787.method_1507(new class_429(this, this.field_22787.field_1690)),
                class_2561.method_43470("Options")
        ));

        this.method_37063(new class_344(
                playerWidgetX,
                buttonY + 43 * this.field_22790 / 1080,
                buttonWidth,
                115 * this.field_22790 / 1080,
                normalButtonTextures,
                button -> playWorld(WorldUtils.getMostRecentSingleplayerWorldName()),
                class_2561.method_43470("Options")
        ));

        Mod.RecentServer last = Mod.loadRecentServer();
        String lastJoinedServerAddress;
        if (last != null) {
            lastJoinedServerAddress = last.address;
            System.out.println(lastJoinedServerAddress);
            this.method_37063(new class_344(
                    playerWidgetX,
                    buttonY + 43 * this.field_22790 / 1080 + 122 * this.field_22790 / 1080,
                    buttonWidth,
                    115 * this.field_22790 / 1080,
                    normalButtonTextures,
                    button -> joinServer(lastJoinedServerAddress),
                    class_2561.method_43470("Options")
            ));
        } else {
            this.method_37063(new class_344(
                    playerWidgetX,
                    buttonY + 43 * this.field_22790 / 1080 + 122 * this.field_22790 / 1080,
                    buttonWidth,
                    115 * this.field_22790 / 1080,
                    normalButtonTextures,
                    button -> this.field_22787.method_1507(new class_500(this)),
                    class_2561.method_43470("Options")
            ));
        }



        this.method_37063(new class_7077(
                buttonX,
                buttonY + 2 * (this.field_22790 * 17 / 1080 + buttonheight),
                buttonWidth,
                buttonheight,
                class_2561.method_43470(""),
                button -> this.field_22787.method_1507(new class_4325(this)),
                field_22793
        ));

        this.method_37063(new class_344(
                buttonX,
                buttonY + 4 * (this.field_22790 * 17 / 1080 + buttonheight),
                buttonWidth,
                buttonheight,
                normalButtonTextures,
                button -> this.field_22787.method_1507(new class_4189(this, this.field_22787.field_1690)),
                class_2561.method_43471("menu.gmod-title-screen.accessibility")
        ));

        this.method_37063(new class_7077(
                buttonX,
                buttonY + 6 * (this.field_22790 * 17 / 1080 + buttonheight),
                buttonWidth,
                buttonheight,
                class_2561.method_43470(""),
                button -> this.field_22787.method_1592(),
                field_22793
        ));

    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        class_4587 matrices = ctx.method_51448();

        int buttonWidth = 408 * this.field_22789 / 1800;
        int logoXMiddle = this.field_22789 / 2 + 400;
        int logoY = getLogoY();
        int gradientWidth = (int)(this.field_22789 * 0.7);

        matrices.method_22903();
        matrices.method_46416(gradientWidth / 2f, this.field_22790 / 2f, 0);
        matrices.method_22907(class_7833.field_40718.rotationDegrees(-90f));
        ctx.method_33284(
                -(int) Math.floor(this.field_22790 / 2f),
                -(int) Math.floor(gradientWidth / 2f) - 1,
                (int) Math.ceil(this.field_22790 / 2f),
                (int) Math.ceil(gradientWidth / 2f),
                0x7b000000, 0x00000000, 0
        );
        matrices.method_22909();

        RenderSystem.setShader(class_10142.field_53879);
        RenderSystem.setShaderTexture(0, AESTHETIC_ELEMENT_DOWN);
        RenderSystem.setShaderTexture(1, AESTHETIC_ELEMENT_UP);
        RenderSystem.setShaderTexture(2, NORMAL_BUTTON_TEXTURE);
        RenderSystem.setShaderTexture(3, REALMS_BUTTON_TEXTURE);
        RenderSystem.setShaderTexture(4, NEWS_BUTTON_TEXTURE);
        RenderSystem.setShaderTexture(5, PLAYER_WIDGET_BUTTON);
        RenderSystem.setShaderTexture(5, RECENTS_BUTTONS);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);

        super.method_25394(ctx, mouseX, mouseY, delta);

        int buttonHeight = buttonWidth * 68 / 408;
        int buttonX = this.field_22789 / 2 - buttonWidth - this.field_22789 * (59 / 2) / 1800;
        int buttonY = this.field_22790 / 2 - this.field_22790 * 298 / 1080;
        int recntsButtonY = buttonY;
        int playerWidgetX = this.field_22789 / 2 + this.field_22789 * (59 / 2) / 1800;
        int playerWidgetY;
        int playerWidgetWidth = 409 * this.field_22789 / 1800;
        int playerWidgetHeight = playerWidgetWidth * 280 / 409;
        int spacing = this.field_22790 * 17 / 1080 + buttonHeight;
        int buttonRenderWidth = 408 * this.field_22789 / 1800;
        int buttonRenderHeight = buttonRenderWidth * 68 / 408;
        int buttonBaseX = this.field_22789 / 2 - buttonRenderWidth - this.field_22789 * (59 / 2) / 1800;
        int buttonCurrentY = this.field_22790 / 2 - this.field_22790 * 298 / 1080;

        for (int i = 0; i < 7; i++) {
            if ((i + 1) % 3 != 0) {
                ctx.method_25290(class_1921::method_62277, NORMAL_BUTTON_TEXTURE, buttonX, buttonY, 0f, 0f, buttonWidth, buttonHeight, buttonWidth, buttonHeight);
            } else if (i == 2) {
                ctx.method_25290(class_1921::method_62277, REALMS_BUTTON_TEXTURE, buttonX, buttonY, 0f, 0f, buttonWidth, buttonHeight, buttonWidth, buttonHeight);
            } else {
                ctx.method_25290(class_1921::method_62277, NEWS_BUTTON_TEXTURE, buttonX, buttonY, 0f, 0f, buttonWidth, buttonHeight, buttonWidth, buttonHeight);
            }

            class_2561[] labels = new class_2561[] {
                    class_2561.method_43471("menu.gmod-title-screen.singleplayer"),
                    class_2561.method_43471("menu.gmod-title-screen.multiplayer"),
                    class_2561.method_43471("menu.gmod-title-screen.realms"),
                    class_2561.method_43471("menu.gmod-title-screen.options"),
                    class_2561.method_43471("menu.gmod-title-screen.modmenu"),
                    class_2561.method_43471("menu.gmod-title-screen.accessibility"),
                    class_2561.method_43471("menu.gmod-title-screen.quit")
            };

            class_2561 label = labels[i];
            int labelWidth = field_22793.method_27525(label);
            int centeredX = buttonBaseX + (buttonRenderWidth - labelWidth) / 2;
            int centeredY = buttonCurrentY + (buttonRenderHeight - field_22793.field_2000) / 2;
            ctx.method_51439(field_22793, label, centeredX, centeredY, 0xFFFFFF, true);

            buttonCurrentY += spacing;
            buttonY += this.field_22790 * 17 / 1080 + buttonHeight;
        }

        playerWidgetY = buttonY - playerWidgetHeight;
        ctx.method_25290(class_1921::method_62277, PLAYER_WIDGET_BUTTON, playerWidgetX, playerWidgetY, 0f, 0f, playerWidgetWidth, playerWidgetHeight, playerWidgetWidth, playerWidgetHeight);

        ctx.method_25290(
                class_1921::method_62277,
                RECENTS_BUTTONS,
                playerWidgetX, recntsButtonY,
                0f, 0f, playerWidgetWidth, playerWidgetWidth * 262 / 409,
                playerWidgetWidth, playerWidgetWidth * 262 / 409
        );

        int textureWidth = this.field_22789;
        int textureHeight = textureWidth * 330 / 1800;
        int y = this.field_22790 - textureHeight;

        for (int x = 0; x < this.field_22789; x += textureWidth) {
            ctx.method_25290(
                    class_1921::method_62277,
                    AESTHETIC_ELEMENT_DOWN,
                    x, y,
                    0f, 0f, textureWidth, textureHeight,
                    textureWidth, textureHeight
            );
        }
        ctx.method_25290(
                class_1921::method_62277,
                AESTHETIC_ELEMENT_UP,
                0, 0,
                0f, 0f, textureWidth, textureHeight,
                textureWidth, textureHeight
        );

        class_327 tr = class_310.method_1551().field_1772;
        String username = class_310.method_1551().method_1548().method_1676();
        int textWidth = tr.method_1727(username);
        ctx.method_51439(
                field_22787.field_1772,
                class_2561.method_43470(username),
                playerWidgetX + playerWidgetWidth / 2 - textWidth / 2,
                playerWidgetY + 16 - 4,
                0xFFFFFF,
                true
        );

        lastLoadedWorld = WorldUtils.getMostRecentSingleplayerWorldName();

        int lastesTextX = playerWidgetX + 189 * this.field_22789 / 1800;
        int lastestWorldTextY = Math.round(recntsButtonY + getFromFigmaHeight(39 + 100 / 2 - 24 / 2) - field_22793.field_2000 / 2);
        int lastestServerTextY = Math.round(lastestWorldTextY + getFromFigmaHeight(115) + field_22793.field_2000 / 2);
        int lastestWorldGamemodeTextY  = Math.round(recntsButtonY + getFromFigmaHeight(39 + 100 / 2 + 24 / 2) + field_22793.field_2000 / 2);
        int lastestServerIPAdress  = Math.round(lastestWorldGamemodeTextY + getFromFigmaHeight(115) + field_22793.field_2000 / 2);
        Mod.RecentServer last = Mod.loadRecentServer();
        String lastJoinedServerName;
        String lastJoinedServerAddress;
        if (last != null) {
            lastJoinedServerName = last.name;
            lastJoinedServerAddress = last.address;
        } else {
            lastJoinedServerAddress = "Null";
            lastJoinedServerName = "No servers/realms joined";
        }

        ctx.method_51439(
                field_22787.field_1772,
                class_2561.method_43470(lastLoadedWorld),
                lastesTextX,
                lastestWorldTextY,
                0xFFFFFF,
                true
        );

        class_2561 gameModeText;

        try {
            gameModeText = class_2561.method_43470(getWorldGameMode(lastLoadedWorld).toString().substring(0, 1).toUpperCase() + getWorldGameMode(lastLoadedWorld).toString().substring(1).toLowerCase());
        } catch (IOException e) {
            gameModeText = class_2561.method_43470("Gamemode: Error");
            e.printStackTrace(); // Or log properly
        }

        ctx.method_51439(
                field_22787.field_1772,
                gameModeText,
                lastesTextX,
                lastestWorldGamemodeTextY,
                0xBEFFFFFF,
                true
        );

        ctx.method_51439(
                field_22787.field_1772,
                class_2561.method_43470(lastJoinedServerAddress),
                lastesTextX,
                lastestServerIPAdress,
                0xBEFFFFFF,
                true
        );

        drawScrollingText(ctx, lastJoinedServerName, lastesTextX, lastestServerTextY, getFromFigmaWidth(200));

        String currentLastLoadedWorld = WorldUtils.getMostRecentSingleplayerWorldName();

        if (!currentLastLoadedWorld.isEmpty() && lastWorldIconTexture == null) {
            Optional<class_2960> iconId = WorldIconLoader.loadWorldIcon(currentLastLoadedWorld);
            iconId.ifPresent(id -> lastWorldIconTexture = id);
        }

        int iconX = Math.round(getFromFigmaWidth(6) + playerWidgetX);
        int iconY = Math.round(getFromFigmaHeight(39 + 8) + recntsButtonY);
        int iconHeight = 99 * screenHeight / 1080;
        int iconWidth = (iconHeight * 16) / 9;

        if (lastWorldIconTexture != null) {
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            ctx.method_25290(class_1921::method_62277, lastWorldIconTexture, iconX, iconY, 0f, 0f, iconWidth, iconHeight, iconWidth, iconHeight);
        } else {
            ctx.method_51439(
                    field_22787.field_1772,
                    class_2561.method_43470("No World Icon"),
                    iconX,
                    iconY,
                    0xFFFFFFFF,
                    true
            );
        }

        logoDrawer.method_48210(ctx, logoXMiddle, 1.0f, logoY);

        this.splashText.method_51453(ctx, logoXMiddle, this.field_22793, 0xFF000000);
        WorldCreationListener.init();
    }

    public static void takeScreenshot(class_310 client) {
        class_329 hud = class_310.method_1551().field_1705;
        hud.field_2013 = 0f;
        Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

        class_276 framebuffer = client.method_1522();

        class_1011 image = class_318.method_1663(framebuffer);


        Path latestWorld = Paths.get(getMostRecentlyCreatedWorld().toString() + "/world_icon.png");

        LOGGER.info("Saved world icon to {}", latestWorld);

        try {
            image.method_4314(latestWorld);
        } catch (IOException e) {
            LOGGER.error("Failed to save world icon", e);
        }
        image.close();
    }

    public static void playWorld(String worldName) {
        class_310 client = class_310.method_1551();

        Path savesDir = client.field_1697.toPath().resolve("saves");
        Path worldDir = savesDir.resolve(worldName);

        if (!Files.exists(worldDir)) {
            System.out.println("World folder doesn't exist: " + worldDir);
            return;
        }

        client.execute(() -> {
            client.method_18099();
            client.method_1507(null); // clear any lingering screen
            client.method_41735().method_57784(worldName, () -> {
                System.out.println("World loaded.");
            });
        });
    }

    private void joinServer(String ipAddress) {
        class_310 client = class_310.method_1551();

        if (client == null) {
            System.err.println("MinecraftClient instance is null. Cannot connect.");
            return;
        }

        class_639 address = class_639.method_2950(ipAddress);

        // For direct IP connections, you typically don't have existing server info
        // or specific cookies to pass. So, null is usually appropriate here.
        class_642 serverInfo = new class_642(ipAddress, ipAddress, class_642.class_8678.field_45611); // name, address, local
        @Nullable class_9112 cookieStorage = null; // No cookies needed for a fresh connection

        client.execute(() -> {
            class_412.method_36877(
                    new class_442(), // Parent screen
                    client,            // MinecraftClient instance
                    address,           // ServerAddress (parsed IP/domain)
                    serverInfo,        // ServerInfo (null for fresh connect by IP)
                    false,             // quickPlay: false for a manual connection
                    cookieStorage      // CookieStorage: null unless you have specific cookie data
            );
            client.field_1705.method_1743().method_1812(class_2561.method_43470("Attempting to connect to: " + ipAddress));
        });
    }

    public static int getFromFigmaHeight(int measure) {
        return (measure * screenHeight / 1080);
    }

    public static int getFromFigmaWidth(int measure) {
        return (measure * screenWidth / 1800);
    }

    private void drawScrollingText(class_332 ctx, String text, int x, int y, int windowWidth) {
        class_327 font = field_22787.field_1772;
        int scrollSpeed = 60; // pixels per second

        String paddedText = text + " ".repeat(30); // space between loops
        int paddedWidth = font.method_1727(paddedText);

        long now = System.currentTimeMillis();
        long elapsed = now - startTime;

        int rawOffset = (int)((elapsed / 1000.0 * scrollSpeed) % paddedWidth);

        // Only pause when first letter is at x=0 (rawOffset == 0)
        int pauseWindow = 2; // pixels of tolerance
        int pauseDuration = 3000; // milliseconds

        if (rawOffset <= pauseWindow && !hasPausedThisLoop) {
            if (!isPaused) {
                isPaused = true;
                lastPauseTime = now;
            }

            if (now - lastPauseTime < pauseDuration) {
                rawOffset = 0; // Freeze scroll
            } else {
                isPaused = false;
                hasPausedThisLoop = true;

                // Adjust startTime to make scrolling seamless
                startTime = now - (long)((pauseWindow / (double)scrollSpeed) * 1000);
            }
        }

        // Reset hasPausedThisLoop when we've clearly moved past the beginning
        if (rawOffset > pauseWindow && hasPausedThisLoop) {
            hasPausedThisLoop = false;
        }

        int startPixel = (paddedWidth - rawOffset + paddedWidth) % paddedWidth;

        String visible = getWrappedVisibleText(font, paddedText, startPixel, windowWidth);
        ctx.method_51433(font, visible, x, y, 0xFFFFFF, false);
    }

    private String getWrappedVisibleText(class_327 font, String text, int startPixel, int windowWidth) {
        StringBuilder sb = new StringBuilder();
        int currentPixel = 0;
        int visiblePixel = 0;
        boolean started = false;

        while (visiblePixel < windowWidth) {
            for (char c : text.toCharArray()) {
                int charWidth = font.method_1727(String.valueOf(c));

                if (!started && currentPixel + charWidth > startPixel) {
                    started = true;
                    int overlap = currentPixel + charWidth - startPixel;
                    visiblePixel += overlap;
                    sb.append(c);
                } else if (started) {
                    visiblePixel += charWidth;
                    if (visiblePixel > windowWidth) break;
                    sb.append(c);
                }

                currentPixel += charWidth;
            }

            // If we reach the end, wrap around to beginning
            if (visiblePixel < windowWidth) {
                currentPixel = 0;
            } else {
                break;
            }
        }

        return sb.toString();
    }
}