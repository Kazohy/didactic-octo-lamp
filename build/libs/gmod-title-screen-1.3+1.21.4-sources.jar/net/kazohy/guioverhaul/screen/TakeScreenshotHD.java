package net.kazohy.guioverhaul.screen;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import static net.fabricmc.loader.impl.FabricLoaderImpl.MOD_ID;

public class TakeScreenshotHD {

}
