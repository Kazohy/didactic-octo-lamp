package net.kazohy.guioverhaul.screen;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kazohy.guioverhaul.ModIdentifier;
import net.minecraft.class_10142;
import net.minecraft.class_1049;
import net.minecraft.class_1060;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5611;
import net.minecraft.class_7833;

@Environment(EnvType.CLIENT)
public class SlideshowBackground {
  private static final class_2960[] BACKGROUNDS = {
    ModIdentifier.of("textures/gui/title/background/background_0.png"),
    ModIdentifier.of("textures/gui/title/background/background_1.png"),
    ModIdentifier.of("textures/gui/title/background/background_2.png"),
    ModIdentifier.of("textures/gui/title/background/background_3.png"),
    ModIdentifier.of("textures/gui/title/background/background_4.png"),
    ModIdentifier.of("textures/gui/title/background/background_5.png"),
    ModIdentifier.of("textures/gui/title/background/background_6.png"),
  };
  private static final Integer[][] BACKGROUND_SIZES = {
    {960, 528},
    {960, 528},
    {960, 528},
    {960, 528},
    {960, 528},
    {960, 528},
    {960, 528},
  };
  private static final float SLIDESHOW_IMAGE_LENGTH = 400f;
  private static final float TRANSITION_LENGTH = 30f;
  private static float t = TRANSITION_LENGTH;

  public static void registerBackgroundTextures(class_1060 textureManager) {
    for (class_2960 background : BACKGROUNDS) {
      textureManager.method_65876(background, new class_1049(background));
    }
  }

  private static void renderBackground(class_332 ctx, float a, int backgroundIndex, float alpha, int width, int height) {
    class_4587 matrices = ctx.method_51448();

    matrices.method_22903();

    class_2960 bg = BACKGROUNDS[backgroundIndex];
    Integer[] backgroundSize = BACKGROUND_SIZES[backgroundIndex];
    float baseScale = Math.max(width / (float) backgroundSize[0], height / (float) backgroundSize[1]);
    class_5611 overscan = new class_5611(backgroundSize[0] * baseScale - width, backgroundSize[1] * baseScale - height);

    RenderSystem.setShader(class_10142.field_53879);
    RenderSystem.setShaderTexture(0, bg);
    RenderSystem.enableBlend();
    RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);

    float scale = class_3532.method_16439(a, 1.1f, 1.2f);
    float angle = class_3532.method_16439(a, -1f, 3f);

    matrices.method_46416(width / 2f, height / 2f, 0f);
    matrices.method_22905(scale, scale, 1f);
    matrices.method_22907(class_7833.field_40718.rotationDegrees(angle));
    ctx.method_25302(
      class_1921::method_62277,
      bg,
      (int) Math.floor(-overscan.method_32118()/2f - width/2f),
      (int) Math.floor(-overscan.method_32119()/2f - height/2f),
      0,
      0,
      width + (int) Math.ceil(overscan.method_32118()),
      height + (int) Math.ceil(overscan.method_32119()),
      1, 1, 1, 1
    );

    matrices.method_46416(width / 2f, height / 2f, 0f);

    matrices.method_22909();
  }

  public static void render(class_332 ctx, float delta, int width, int height) {
    t += delta;

    int index = (int) Math.floor(t / SLIDESHOW_IMAGE_LENGTH) % BACKGROUNDS.length;
    int previousIndex = (index - 1 + BACKGROUNDS.length) % BACKGROUNDS.length;
    float a = (t % SLIDESHOW_IMAGE_LENGTH) / SLIDESHOW_IMAGE_LENGTH;
    float transition = class_3532.method_15363(a / (TRANSITION_LENGTH / SLIDESHOW_IMAGE_LENGTH), 0f, 1f);

    if (transition < 1f) {
      renderBackground(ctx, a + 1f, previousIndex, 1f, width, height);
    }
    renderBackground(ctx, a, index, transition, width, height);
  }
}
