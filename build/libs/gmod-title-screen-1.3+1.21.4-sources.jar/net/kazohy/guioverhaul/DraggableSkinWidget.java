package net.kazohy.guioverhaul;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_490;
import net.minecraft.class_6382;
import net.minecraft.class_746;
import org.joml.Quaternionf;
import org.joml.Vector3f;


public class DraggableSkinWidget extends class_339 {
    private boolean dragging;
    private double dragOffsetX, dragOffsetY;

    public DraggableSkinWidget(int x, int y, int width, int height) {
        super(x, y, width, height, class_2561.method_43473());
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        // Draw a translucent background or border (optional)
        // context.fill(getX(), getY(), getX()+width, getY()+height, 0x80000000);

        // Render the local player in 3D at the center of this widget
        class_746 player = class_310.method_1551().field_1724;
        if (player != null) {
            int centerX = this.method_46426() + this.field_22758 / 2;
            int centerY = this.method_46427() + this.field_22759 / 2;
            float size = 30.0f; // scale of the model

            // Offset the model so it is vertically centered
            Vector3f vector = new Vector3f(0.0f, player.method_17682() / 2.0f, 0.0f);
            // Rotate model to face the camera (flip by PI radians)
            Quaternionf rot = new Quaternionf().rotateZ((float)Math.PI);

            // Draw the entity using InventoryScreen.drawEntity
            class_490.method_48472(
                    context,
                    centerX, centerY, size,
                    vector, rot, /* no extra pitch */ null,
                    player
            );
        }
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        // Begin dragging: record offset between mouse and widget origin
        this.dragging = true;
        this.dragOffsetX = mouseX - this.method_46426();
        this.dragOffsetY = mouseY - this.method_46427();
    }

    @Override
    public void method_25349(double mouseX, double mouseY, double deltaX, double deltaY) {
        // If dragging, update widget position
        if (this.dragging) {
            this.method_46421((int)(mouseX - this.dragOffsetX));
            this.method_46419((int)(mouseY - this.dragOffsetY));
        }
    }

    @Override
    public void method_25357(double mouseX, double mouseY) {
        // Stop dragging on release
        this.dragging = false;
    }

    @Override
    protected void method_47399(class_6382 builder) {
        // No-op for now (or add a descriptive narration if you want)
    }
}