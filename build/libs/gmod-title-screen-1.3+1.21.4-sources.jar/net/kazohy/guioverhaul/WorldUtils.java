package net.kazohy.guioverhaul;

import com.mojang.datafixers.types.templates.Tag;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.util.NbtType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1934;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_310;
import net.minecraft.class_32;
import net.minecraft.class_32.class_7410;
import net.minecraft.class_34;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

import java.util.Comparator;
import java.util.List;
import java.util.zip.GZIPInputStream;

import static com.mojang.text2speech.Narrator.LOGGER;

public class WorldUtils {
    public static String getMostRecentSingleplayerWorldName() {
        class_310 client = class_310.method_1551();
        class_32 storage = client.method_1586();

        try {
            class_7410 levelList = storage.method_235();
            List<class_34> summaries = storage.method_43417(levelList)
                    .thenApply(list -> list.stream()
                            .sorted(Comparator.comparing(class_34::method_249).reversed())
                            .toList()
                    )
                    .join(); // block until ready

            if (!summaries.isEmpty()) {
                return summaries.get(0).method_248();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        return "No worlds played";
    }


    public static class_1934 getWorldGameMode(String worldName) throws IOException {
        // Point to default saves folder (relative to run directory)
        File worldDirectory = new File("saves", worldName);
        File levelDat = new File(worldDirectory, "level.dat");

        if (!levelDat.exists()) {
            throw new IOException("level.dat not found for world: " + worldName);
        }

        try (FileInputStream fis = new FileInputStream(levelDat)) {
            class_2487 nbt = class_2507.method_10629(fis, class_2505.method_53898());

            if (nbt == null || !nbt.method_10545("Data")) {
                throw new IOException("Invalid level.dat structure in world: " + worldName);
            }

            class_2487 data = nbt.method_10562("Data");

            // Check for hardcore first
            if (data.method_10545("hardcore") && data.method_10577("hardcore")) {
                return class_1934.field_9215;
            }

            int gameType = data.method_10550("GameType");

            return switch (gameType) {
                case 0 -> class_1934.field_9215;
                case 1 -> class_1934.field_9220;
                case 2 -> class_1934.field_9216;
                case 3 -> class_1934.field_9219;
                default -> throw new IOException("Unknown GameType: " + gameType);
            };
        }
    }
}