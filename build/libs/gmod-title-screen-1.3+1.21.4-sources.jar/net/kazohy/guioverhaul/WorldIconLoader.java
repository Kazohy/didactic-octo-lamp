package net.kazohy.guioverhaul;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

import static net.fabricmc.loader.impl.FabricLoaderImpl.MOD_ID;

public class WorldIconLoader {
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID); // Use your mod's logger
    private static final Map<String, class_2960> cachedWorldIcons = new HashMap<>(); // Cache to avoid reloading

    /**
     * Loads the icon.png for a given world name and registers it with the texture manager.
     * Caches the loaded texture identifier to prevent redundant loading.
     *
     * @param worldName The name of the world (e.g., "My Super World")
     * @return An Optional containing the Identifier of the loaded texture, or empty if failed.
     */
    public static Optional<class_2960> loadWorldIcon(String worldName) {
        // Check cache first
        if (cachedWorldIcons.containsKey(worldName)) {
            return Optional.of(cachedWorldIcons.get(worldName));
        }

        class_310 client = class_310.method_1551();
        if (client == null) {
            return Optional.empty(); // Should not happen in client-side context, but for safety
        }

        // Get the path to the saves folder
        Path savesFolderPath = client.field_1697.toPath().resolve("saves");
        File worldFolder = savesFolderPath.resolve(worldName).toFile(); // Assuming worldName is the folder name

        if (!worldFolder.isDirectory()) {
            LOGGER.warn("World folder not found: {}", worldFolder.getAbsolutePath());
            return Optional.empty();
        }

        File iconFile = new File(worldFolder, "world_icon.png");

        if (!iconFile.exists()) {
            LOGGER.warn("icon.png not found for world: {}", worldName);
            return Optional.empty();
        }

        try (InputStream is = new FileInputStream(iconFile)) {
            class_1011 image = class_1011.method_4309(is);
            if (image == null) {
                LOGGER.warn("Failed to read image from icon.png for world: {}", worldName);
                return Optional.empty();
            }

            // Create a new NativeImageBackedTexture from the loaded image
            class_1043 texture = new class_1043(image);

            // Generate a unique Identifier for this texture
            // Using a custom namespace and a world-specific path for uniqueness
            class_2960 textureId = ModIdentifier.of("world_icons/" + worldName.toLowerCase().replaceAll("[^a-z0-9/._-]", "_"));

            // Register the texture with Minecraft's TextureManager
            client.method_1531().method_4616(textureId, texture);

            // Cache the identifier
            cachedWorldIcons.put(worldName, textureId);
            LOGGER.info("Successfully loaded and registered world icon for: {}", worldName);
            return Optional.of(textureId);

        } catch (IOException e) {
            LOGGER.error("Error loading world icon for world {}: {}", worldName, e.getMessage());
            return Optional.empty();
        }
    }
}