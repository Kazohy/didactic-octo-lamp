package net.kazohy.guioverhaul;



import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_3675;
import net.minecraft.class_638;
import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.function.Consumer;

public class GuiLessScreenshotMod implements ClientModInitializer {

    // Declare your KeyBinding instance
    private static class_304 guiLessScreenshotKey;

    // This method is called when the client-side of your mod is initialized.
    @Override
    public void onInitializeClient() {
        // 1. Define the KeyBinding
        // Parameters:
        //   - Identifier: A unique translation key for the keybind name (e.g., "key.guilessscreenshot.capture")
        //   - InputType: Specifies if it's a keyboard key (InputUtil.Type.KEYSYM) or mouse button
        //   - Default Key Code: The default key (e.g., GLFW.GLFW_KEY_F12 for F12)
        //   - Category: A translation key for the category name in Minecraft's controls settings
        guiLessScreenshotKey = new class_304(
                "key.guilessscreenshot.capture",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F12, // Default key is F12
                class_2561.method_43471("key.categories.guilessscreenshot").getString() // Category name in settings
        );

        // 2. Register the KeyBinding with Fabric
        KeyBindingHelper.registerKeyBinding(guiLessScreenshotKey);

        // 3. Register a client tick event listener
        // This event fires at the end of every client tick.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Check if the custom keybinding is pressed
            if (guiLessScreenshotKey.method_1434()) {
                // If pressed, call our method to take the GUI-less screenshot
                takeGuiLessScreenshot(client);
            }
        });
    }

    /**
     * Handles the logic for taking a screenshot without the GUI.
     * This method is called when the custom keybinding is pressed.
     *
     * @param client The current MinecraftClient instance.
     */
    private void takeGuiLessScreenshot(class_310 client) {
        // 1. Ensure the player is in a world (not on the main menu, etc.)
        if (client.field_1687 == null) {
            // Send a chat message to the player if they are not in a world
            client.field_1705.method_1743().method_1812(class_2561.method_43470("Cannot take screenshot: Not in a world."));
            return; // Exit the method early
        }

        // 2. Store the current GUI visibility state
        // This allows us to restore the GUI to its original state after the screenshot.
        boolean wasHudHidden = client.field_1690.field_1842;

        // 3. Temporarily hide the GUI
        // This is the core step to get a GUI-less view.
        client.field_1690.field_1842 = true;

        // 4. Schedule the actual screenshot capture on the main client thread.
        // This is crucial for thread safety, as GUI updates and rendering calls
        // must happen on the main thread. The 'execute' method ensures this.
        client.execute(() -> {
            // Determine the directory where the screenshot will be saved.
            // Option A: Use Minecraft's default screenshots directory (usually .minecraft/screenshots)
            File screenshotsDir = new File(client.field_1697, "screenshots");

            // Option B: Save to the current world's save directory (uncomment and use this if preferred)
            File worldDirectory = null;
            class_638 currentWorld = client.field_1687;
            if (currentWorld != null && client.method_1586() != null) {
                try {
                    // Get the path to the current world's save folder
                    // This method might vary slightly with Minecraft versions, but WorldSavePath.ROOT is reliable.
                    Path worldSavePath = client.method_1586().method_19636().resolve(currentWorld.method_27983().method_29177().method_12832());
                    worldDirectory = worldSavePath.toFile();
                    // Ensure the directory exists
                    if (!worldDirectory.exists()) {
                        worldDirectory.mkdirs();
                    }
                } catch (Exception e) {
                    // Log any errors if unable to get world directory
                    System.err.println("Error getting world directory: " + e.getMessage());
                    client.field_1705.method_1743().method_1812(class_2561.method_43470("Error getting world directory for screenshot."));
                    // Fallback to default screenshots directory if world directory cannot be found
                    worldDirectory = screenshotsDir;
                }
            } else {
                // Fallback to default screenshots directory if world or level storage is null
                worldDirectory = screenshotsDir;
            }

            // Ensure the chosen directory exists
            if (!worldDirectory.exists()) {
                worldDirectory.mkdirs();
            }

            // Define the callback for when the screenshot saving process is complete.
            // This consumer receives a Text object with a success or failure message.
            Consumer<class_2561> screenshotCallback = (message) -> {
                // Restore GUI visibility to its original state after the screenshot is saved.
                client.field_1690.field_1842 = wasHudHidden;
                // Display the success/failure message in the player's chat.
                client.field_1705.method_1743().method_1812(message);
            };

            // Call Minecraft's built-in ScreenshotRecorder to capture and save the screenshot.
            // This method handles capturing the framebuffer, encoding to PNG, and writing to file.
            String filename = "player_view_" + new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date()) + ".png";

            class_318.method_22690(
                    worldDirectory,             // The directory to save the screenshot to
                    filename,                   // The generated unique filename
                    client.method_1522(),        // The current framebuffer to capture
                    screenshotCallback              // The callback to execute after saving
            );
        });
    }
}
