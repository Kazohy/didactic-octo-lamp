package net.kazohy.guioverhaul.mixin;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.kazohy.guioverhaul.screen.CustomTitleScreen;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;

// this sucks. lmao.
@Mixin(class_310.class)
public class RedirectTitleScreenMixin {
  @Redirect(method = "setScreen", at = @At(value = "FIELD", target = "Lnet/minecraft/client/MinecraftClient;currentScreen:Lnet/minecraft/client/gui/screen/Screen;", opcode = Opcodes.PUTFIELD))
  private void injected(class_310 instance, class_437 value) {
    if (value instanceof class_442) {
      //instance.currentScreen = new CustomTitleScreen();
      // this causes a fabric api error of all things, so let's do a little redundancy, shall we?
      instance.method_1507(new CustomTitleScreen());
      // yes. Wonderful. let's fucking call it Twice.
      // (i genuinely could not find anything that Isn't this)
    } else {
      instance.field_1755 = value;
    }
  }
}
