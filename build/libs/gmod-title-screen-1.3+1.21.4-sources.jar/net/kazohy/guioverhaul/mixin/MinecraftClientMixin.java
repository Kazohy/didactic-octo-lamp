package net.kazohy.guioverhaul.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.kazohy.guioverhaul.screen.CustomTitleScreen;
import net.minecraft.class_1060;
import net.minecraft.class_310;
import net.minecraft.class_542;

// this sucks. lmao.
@Mixin(class_310.class)
public class MinecraftClientMixin {
  @Shadow @Final private class_1060 textureManager;

  @Inject(method = "Lnet/minecraft/client/MinecraftClient;<init>(Lnet/minecraft/client/RunArgs;)V", at = @At("TAIL"))
  private void constructor(class_542 args, CallbackInfo ci) {
    CustomTitleScreen.registerTextures(textureManager);
  }
}
